var gulp = require('gulp');
var handlebars = require('gulp-handlebars');
var declare = require('gulp-declare');
var wrap = require('gulp-wrap');
var concat = require('gulp-concat');
var concatCss = require('gulp-concat-css');
var uglify = require('gulp-uglify');
var change = require('gulp-change');
var cssmin = require('gulp-cssmin');
var watch = require('gulp-watch');
var htmlclean = require('gulp-htmlclean');
var clean = require('gulp-clean');
//var stripcomments = require('gulp-strip-comments');
//var stripcomments = require('remove-html-comments');

gulp.task('clean', function () {
    return gulp
    .src('./public', {read: false})
    .pipe(clean());
});

gulp.task('html',['clean'],function(){
	return gulp
	.src([
	  './build/**/*'
	])
	.pipe(gulp.dest('./public'));
	/*
	//.pipe(stripcomments({safe:false}))
	//.on('error', gutil.log)
	.pipe(change(function(content){
	//return '"'+collapseWhiteSpace(removeBreaks(content)).replace(/"/g, '\\"').replace('{{ASSETS_URL}}',hbsData['assetsDirectory'])+'"';
	return '"'+collapseWhiteSpace(removeBreaks(content)).replace(/"/g, '\\"')+'"';
	}))
	.pipe(change(function(content){
	return 'Handlebars.compile('+content+')';
	}))
	.pipe(declare({
	namespace: 'GlobalTemplates',
	noRedeclare: true
	}))
	.pipe(concat('TMP_templates.js'))
	.pipe(gulp.dest('./js'));*/
})

gulp.task('jsmin', ['html','clean'], function() {
	return gulp
	.src('./public/**/*.js')
    .pipe(uglify())
    .pipe(gulp.dest('./public'));
});

gulp.task('default',['html','jsmin','clean'],function(){
	return gulp;
});
